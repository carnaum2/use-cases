Rscript 1_get_convergent_customers.R --month 201701
Rscript 1_get_convergent_customers.R --month 201702
Rscript 1_get_convergent_customers.R --month 201703
Rscript 1_get_convergent_customers.R --month 201704
#Rscript 1_get_convergent_customers.R --month 201705
#Rscript 1_get_convergent_customers.R --month 201706

#Rscript 1_get_conv_car.R
#Rscript 2_prepare_conv_train_dataset.R
#Rscript 2_prepare_conv_test_dataset.R


