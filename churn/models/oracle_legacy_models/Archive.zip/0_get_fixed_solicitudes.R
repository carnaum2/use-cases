source("configuration.R")

main <- function(month) {
  
  ifile <- paste0("/Users/fcastanf/Desktop/CVM-Fede/input/WinBack/neg_lineas_", month, ".csv")
  cat("[LOAD]", ifile, "\n")
  dt.solicitudes <- fread(ifile)
  
  dt.solicitudes <- dt.solicitudes[substr(MSISDN, 1, 2)=="VF"]
  dt.solicitudes <- dt.solicitudes[, "MSISDN", with = F]
  dt.solicitudes <- unique(dt.solicitudes, by = "MSISDN")
  cat("[INFO] ", nrow(dt.solicitudes), " Winback rows \n")
  
  # Add fixed bajas from CVM
  ifile <- paste0("/Users/fcastanf/Desktop/CVM-Fede/input/CVM/", month, "/EXTR_CVM_DESACT_FIJO_", month, ".TXT")
  cat("[LOAD]", ifile, "\n")
  dt.solicitudes.fijo <- fread(ifile)
  dt.solicitudes.fijo <- dt.solicitudes.fijo[GRUPOMOTIVO == "BAJA ADSL" | GRUPOMOTIVO == "BAJA FTTH"]
  
  dt.solicitudes.fijo <- dt.solicitudes.fijo[, .(X_ID_RED)]
  setnames(dt.solicitudes.fijo, "X_ID_RED", "MSISDN")
  dt.solicitudes.fijo <- dt.solicitudes.fijo[!MSISDN %in% dt.solicitudes$MSISDN]
  
  dt.solicitudes <- rbind(dt.solicitudes, dt.solicitudes.fijo)

  cat("[INFO] ", nrow(dt.solicitudes), " Total rows \n")
  ofile <- paste0(cvm.data.folder, month, "/dt.solicitudes.fixed.RData") 
  cat("[SAVE] ", ofile, "\n")
  save(dt.solicitudes, file = ofile)
}

#---------------------------------------------------------------------------------------------------
option_list <- list(
  make_option(c("-m", "--month"), type = "character", default = NULL, help = "input date (YYYYMMDD)", 
              metavar = "character")
)

opt_parser <- OptionParser(option_list = option_list)
opt <- parse_args(opt_parser)

if (is.null(opt$month)) {
  print_help(opt_parser)
  stop("At least one parameter must be supplied (input month: YYYYMM)", call.=FALSE)
} else {
  main(opt$month)
}