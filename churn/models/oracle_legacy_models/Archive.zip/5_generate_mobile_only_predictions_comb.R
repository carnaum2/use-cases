source("configuration.R")

getDeciles <- function(preds, nile = 10) {
  numobsperdec <- round(length(preds)/nile)
  idxordpreds <- order(preds, decreasing = T)
  
  decile.label <- rep(0, length(preds))
  
  for(i in nile:1) {
    temp <- idxordpreds[((nile-i)*numobsperdec+1):((nile-i+1)*numobsperdec)]
    decile.label[temp] <- i
    rm(temp)
  }
  
  deciles.output <- list(data = preds, label = decile.label, idx = idxordpreds)
  
  deciles.output
}

generateDataSet <- function(dt.car.mo) {
  remove.cols <- c(      
    "NUM_FACT_SIN_SMS_M0"  , "SEG_NACIONALIDAD",
    "NUM_FACT_INTERNAC_M0",  "NUM_ACCESOS_3G_M0", "NUM_DATOS_3G_M0"      
  )
  
  dt.car.mo <- dt.car.mo[, !remove.cols, with = F]
  
  dt.car.mo[, SEG_TIPO_IDENT := as.factor(SEG_TIPO_IDENT)]
  dt.car.mo[, SEG_DESCUENTO_MAX := as.factor(SEG_DESCUENTO_MAX)]
  dt.car.mo[, SEG_SISTEMA_OPERATIVO:= as.factor(SEG_SISTEMA_OPERATIVO)]
  dt.car.mo[, SEG_TIPO_HOGAR_HH := as.factor(SEG_TIPO_HOGAR_HH)]
  dt.car.mo[, SEG_CICLO_VIDA := as.factor(SEG_CICLO_VIDA)]
  #dt.valid[, SEG_NACIONALIDAD := as.factor(SEG_NACIONALIDAD)]
  dt.car.mo[, SEG_SEXO := as.factor(SEG_SEXO)]
}

predictH2OGBM <- function(model.month, pred.hex) {
  ifile <- paste0(models.folder, "/", model.month, "/gbm.model.h2o/h2ogbm")
  cat("[LOAD] ", ifile, "\n")
  
  h2ogbm <- h2o.loadModel(ifile)
  
  pred.1 <- h2o.predict(object = h2ogbm, newdata = pred.hex)
  
  pred.1 <- as.data.frame(pred.1)
  
  return(pred.1[,3])
}

main <- function(model.month, car.month, model.type, out.date) {
  
  ifile <- paste0(acc.data.folder, car.month, "/dt.car.mo.", car.month, ".RData")
  cat("[LOAD]", ifile, "\n")
  load(ifile)
  
  dt.car.mo <- generateDataSet(dt.car.mo)
  
  if (model.type == "rf") {
    dt.preds  <- predictRF(model.month, dt.car.mo)
    
  } else if (model.type == "xg") {
    dt.preds <- predictXG(model.month, dt.car.mo)
    
  } else if (model.type == "h2orf") {
    
    localH2O = h2o.init(nthreads = -1, max_mem_size = "10G", enable_assertions = F)
    h2o.removeAll()
    cat("[INFO] Loading Data into H2O Cluster...\n")
    pred.hex <- as.h2o(dt.car.mo, "pred.hex")
    
    dt.preds  <- predictH2ORF(model.month, pred.hex)
    h2o.shutdown(prompt = F)
    
  } else if (model.type == "h2ogbm") {

    localH2O = h2o.init(nthreads = -1, max_mem_size = "10G", enable_assertions = F)
    h2o.removeAll()
    cat("[INFO] Loading Data into H2O Cluster...\n")
    pred.hex <- as.h2o(dt.car.mo, "pred.hex")
    
    dt.preds  <- predictH2OGBM(model.month, pred.hex)
    h2o.shutdown(prompt = F)
    
  } else if (model.type == "combined") {
    
    localH2O = h2o.init(nthreads = -1, max_mem_size = "10G", enable_assertions = F)
    h2o.removeAll()
    cat("[INFO] Loading Data into H2O Cluster...\n")
    pred.hex <- as.h2o(dt.car.mo, "pred.hex")
    
    pred.1  <- evaluateH2ORF(month, pred.hex)
    pred.2  <- evaluateH2OGBM(month, pred.hex)
    
    h2o.shutdown(prompt = F)
    
    dt.preds <- (.5 * pred.1) + (.5 * pred.2)
  }
  
  dt.preds <- as.data.table(dt.preds)

  # Combinacion ambos ficheros
  dt.preds <- cbind(dt.preds, dt.car.mo[, c("MSISDN"), with = F])
  setnames(dt.preds, c("score_churn_cartera_red_bd", "msisdn"))
  
  dt.preds[, ind_propenso_churn_cartera_red_bd := 0]
  #dt.preds[score_churn_cartera_red_bd >= median(score_churn_cartera_red_bd), ind_propenso_churn_cartera_red_bd := 1]
  dt.preds[score_churn_cartera_red_bd >= .5, ind_propenso_churn_cartera_red_bd := 1]
  
  deciles.bd <- getDeciles(dt.preds[ind_propenso_churn_cartera_red_bd==1]$score_churn_cartera_red_bd)
  dt.preds[ind_propenso_churn_cartera_red_bd==1, dec_prop_sc_churn_cartera_red_bd := deciles.bd$label]
  
  setkey(dt.preds, msisdn)
  
  # Fichero Accenture
  ifile <- paste0(acc.output.folder, car.month, "/cartera_scoring_par_churn_", car.month, ".txt")
  cat("[LOAD]", ifile, "\n")
  dt.cartera.scoring <- fread(ifile, na.strings = c("\\N"))
  
  col.names <- c("msisdn", "nif", "score_churn_cartera_red", "score_churn_cartera", "score_pc_cartera", "ind_propenso_porta", "ind_propenso_pecli",
                 "nif_compartido", "segmento", "fact_3m", "ind_exclusion", "ind_propenso_churn_cartera_red", "dec_prop_sc_churn_cartera_red")
  
  setnames(dt.cartera.scoring, col.names)  
  dt.cartera.scoring[, msisdn := as.character(msisdn)]
  setkey(dt.cartera.scoring, msisdn)
  
  dt.cartera.scoring.comb <- dt.preds[dt.cartera.scoring]
  
  col.order <- c("msisdn", "nif", "score_churn_cartera_red",          
      "score_churn_cartera", "score_pc_cartera", "ind_propenso_porta",               
      "ind_propenso_pecli", "nif_compartido", "segmento",                          
      "fact_3m", "ind_exclusion", "ind_propenso_churn_cartera_red",   
      "dec_prop_sc_churn_cartera_red" , "score_churn_cartera_red_bd",  "ind_propenso_churn_cartera_red_bd", 
      "dec_prop_sc_churn_cartera_red_bd" )

  setcolorder(dt.cartera.scoring.comb, col.order)  

  dt.cartera.scoring.comb[, score_churn_cartera_red := as.numeric(score_churn_cartera_red)]
  dt.cartera.scoring.comb[, score_churn_cartera := as.numeric(score_churn_cartera)]
  dt.cartera.scoring.comb[, score_pc_cartera := as.numeric(score_pc_cartera)]
  dt.cartera.scoring.comb[, dec_prop_sc_churn_cartera_red_bd := as.character(dec_prop_sc_churn_cartera_red_bd)]
  dt.cartera.scoring.comb[, ind_propenso_churn_cartera_red_bd := as.integer(ind_propenso_churn_cartera_red_bd)]
  
  dt.cartera.scoring.comb[!is.na(score_churn_cartera_red_bd), score_churn_cartera_red_comb := score_churn_cartera_red_bd]
  dt.cartera.scoring.comb[is.na(score_churn_cartera_red_bd), score_churn_cartera_red_comb := score_churn_cartera_red]
  
  dt.cartera.scoring.comb[!is.na(score_churn_cartera_red_bd), dec_prop_sc_churn_cartera_red_comb := dec_prop_sc_churn_cartera_red_bd]
  dt.cartera.scoring.comb[is.na(score_churn_cartera_red_bd), dec_prop_sc_churn_cartera_red_comb := dec_prop_sc_churn_cartera_red]
  
  dt.cartera.scoring.comb[!is.na(score_churn_cartera_red_bd), ind_propenso_churn_cartera_red_comb := ind_propenso_churn_cartera_red_bd]
  dt.cartera.scoring.comb[is.na(score_churn_cartera_red_bd), ind_propenso_churn_cartera_red_comb := ind_propenso_churn_cartera_red]
  
  dt.cartera.scoring.comb[, dec_prop_sc_churn_cartera_red_comb := as.numeric(dec_prop_sc_churn_cartera_red_comb)]
  dt.cartera.scoring.comb[, dec_prop_sc_churn_cartera_red := as.numeric(dec_prop_sc_churn_cartera_red)]
  
  col.order <- c("score_churn_cartera_red_bd", "msisdn", "ind_propenso_churn_cartera_red_bd", 
                 "nif", "score_churn_cartera", "score_pc_cartera", "ind_propenso_porta", 
                 "ind_propenso_pecli", "nif_compartido", "segmento", "fact_3m", 
                 "ind_exclusion", "ind_propenso_churn_cartera_red", "dec_prop_sc_churn_cartera_red", 
                 "ind_propenso_churn_cartera_red_comb", 
                 "dec_prop_sc_churn_cartera_red_bd",
                 "dec_prop_sc_churn_cartera_red_comb",
                 "score_churn_cartera_red",
                 "score_churn_cartera_red_comb"
                 )
  
  setcolorder(dt.cartera.scoring.comb, col.order)
  
  dt.cartera.scoring.comb[, MONOLINE := 0]
  dt.cartera.scoring.comb[!is.na(score_churn_cartera_red_bd), MONOLINE := 1]
  
  ofolder <- preds.folder
  if (!file.exists(ofolder)) {
    cat("[INFO] Creating Folder\n")
    dir.create(ofolder, recursive = T)
  }
  ofile <- paste0(ofolder, "/cartera_scoring_par_churn_comb_", car.month, ".txt")
  cat("[SAVE]", ofile, "\n")
  write.table(dt.cartera.scoring.comb, file = ofile, quote = F, sep = "\t", row.names = F)
}

#---------------------------------------------------------------------------------------------------------
main("201706", "201708", "h2ogbm")

#option_list <- list(
#  make_option(c("-mm", "--model_month"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character"),
#  make_option(c("-dm", "--data_month"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character"),
#  make_option(c("-model", "--model_type"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character")
#)

#opt_parser <- OptionParser(option_list = option_list)
#opt <- parse_args(opt_parser)

#if (is.null(opt$month)) {
#  print_help(opt_parser)
#  stop("At least one parameter must be supplied (input month: YYYYMM)", call.=FALSE)
#} else {
#  main(opt$model_month, opt$data_month, opt$model_type)
#}
