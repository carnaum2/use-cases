source("configuration.R")

getDeciles <- function(preds, nile = 10) {
  numobsperdec <- round(length(preds)/nile)
  idxordpreds <- order(preds, decreasing = T)
  
  decile.label <- rep(0, length(preds))
  
  for(i in nile:1) {
    temp <- idxordpreds[((nile-i)*numobsperdec+1):((nile-i+1)*numobsperdec)]
    decile.label[temp] <- i
    rm(temp)
  }
  
  deciles.output <- list(data = preds, label = decile.label, idx = idxordpreds)
  
  deciles.output
}

generateDataSet <- function(dt.car) {
 
  dt.car[, SEG_TIPO_IDENT := as.factor(SEG_TIPO_IDENT)]
  dt.car[, SEG_DESCUENTO_MAX := as.factor(SEG_DESCUENTO_MAX)]
  dt.car[, SEG_SISTEMA_OPERATIVO:= as.factor(SEG_SISTEMA_OPERATIVO)]
  #dt.car[, SEG_TIPO_HOGAR_HH := as.factor(SEG_TIPO_HOGAR_HH)]
  dt.car[, SEG_CICLO_VIDA := as.factor(SEG_CICLO_VIDA)]
  #dt.car[, SEG_NACIONALIDAD := as.factor(SEG_NACIONALIDAD)]
  dt.car[, SEG_SEXO := as.factor(SEG_SEXO)]
  
return(dt.car)
}

predictH2OGBM <- function(model.month, pred.hex) {
  ifile <- paste0(models.folder, "/", model.month, "/gbm.model.h2o.conv/h2ogbm")
  cat("[LOAD] ", ifile, "\n")
  
  h2ogbm <- h2o.loadModel(ifile)
  
  pred.1 <- h2o.predict(object = h2ogbm, newdata = pred.hex)
  
  pred.1 <- as.data.frame(pred.1)
  
  return(pred.1[,3])
}

main <- function(model.month, car.month, model.type, out.date) {
  
  ifile <- paste0(churn.datasets.folder, "/dt.test.conv.", car.month,".RData")
  cat("[LOAD]", ifile, "\n")
  load(ifile)
  dt.test <- generateDataSet(dt.test)
  
  if (model.type == "h2ogbm") {

    localH2O = h2o.init(nthreads = -1, max_mem_size = "10G", enable_assertions = F)
    h2o.removeAll()
    cat("[INFO] Loading Data into H2O Cluster...\n")
    pred.hex <- as.h2o(dt.test, "pred.hex")
    
    dt.preds.conv  <- predictH2OGBM(model.month, pred.hex)
    h2o.shutdown(prompt = F)
    
  }
  else {
    cat("Error in model type\n")
    return -1
  }
  
  dt.preds.conv <- as.data.table(dt.preds.conv)

  setnames(dt.preds.conv, "score_churn_cartera_red_bd")
  dt.preds.conv <- cbind(dt.test[, "MSISDN", with = F], dt.preds.conv)
  dt.preds.conv[, score_churn_cartera_red_bd := round(score_churn_cartera_red_bd, digits = 2)]
  
  ofolder <- preds.folder
  if (!file.exists(ofolder)) {
    cat("[INFO] Creating Folder\n")
    dir.create(ofolder, recursive = T)
  }
  ofile <- paste0(ofolder, "/convergente/dt.preds.conv.", car.month, ".RData")
  cat("[SAVE]", ofile, "\n")
  save(dt.preds.conv, file = ofile)
}

#---------------------------------------------------------------------------------------------------------
#main("201706", "201708", "h2ogbm")
#main("201709", "201711", "h2ogbm")
#main("201710", "201712", "h2ogbm")
#main("201711", "201801", "h2ogbm")
#main("201712", "201802", "h2ogbm")
#main("201801", "201803", "h2ogbm")
#main("201802", "201804", "h2ogbm")
#main("201803", "201805", "h2ogbm")
#main("201804", "201806", "h2ogbm")
#main("201805", "201807", "h2ogbm")
#main("201806", "201808", "h2ogbm")
#main("201807", "201809", "h2ogbm")
#main("201808", "201810", "h2ogbm")
#main("201809", "201811", "h2ogbm")
#main("201810", "201812", "h2ogbm")
main("201811", "201901", "h2ogbm")


#main("201807", "201808-2M", "h2ogbm")
#main("201807", "201808-2O", "h2ogbm")

#option_list <- list(
#  make_option(c("-mm", "--model_month"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character"),
#  make_option(c("-dm", "--data_month"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character"),
#  make_option(c("-model", "--model_type"), type = "character", default = NULL, help = "input month (YYYYMM)", 
#              metavar = "character")
#)

#opt_parser <- OptionParser(option_list = option_list)
#opt <- parse_args(opt_parser)

#if (is.null(opt$month)) {
#  print_help(opt_parser)
#  stop("At least one parameter must be supplied (input month: YYYYMM)", call.=FALSE)
#} else {
#  main(opt$model_month, opt$data_month, opt$model_type)
#}
