source("configuration.R")

main <- function(month) {
  
  if (!month  %in% c("201704", "201703", "201702", "201701")) {
    ifile <- paste0(acc.input.folder, month, "/PAR_EXPLIC_LIN_6M_", month, ".txt")
    cat("[LOAD]", ifile, "\n")
    dt.car <- fread(ifile, sep = "\t", na.strings = c("NULL","\\N"))
    
    # Set Header
    ifile <- paste0(acc.input.folder, month, "/header_CBU.txt")
    cat("[LOAD]", ifile, "\n")
    dt.header <- fread(ifile)
    names(dt.car) <- toupper(names(dt.header))
  } else {
    ifile <- paste0(acc.input.folder, month, "/PAR_EXPLIC_LIN_6M_", month, "_.txt")
    cat("[LOAD]", ifile, "\n")
    dt.car <- fread(ifile, sep = "\t", na.strings = c("NULL"))
  }
  
  cat(str(dt.car))
  if(!is.numeric(dt.car$NUM_ARPU_AVG)) {
    cat("[ERROR] Numeric variables are readed as Strings. Check Header inside File\n")
    return(-1)
  }
  
  dt.car <- dt.car[IND_LINEA_VOZ == 1,]
  
  setkey(dt.car, NIF)
  
  ifile <- paste0(datasets.folder, "/", month, "/dt.Convergentes-NIFS-", month, ".RData")
  cat("[LOAD] ", ifile, "\n")
  load(ifile)
  
  dt.car <- dt.car[NIF %in% dt.Convergentes$x_num_ident]
  
  dt.car[is.null(dt.car)] <- -1
  dt.car[is.na(dt.car)] <- -1
  
  ofolder <- paste0(acc.data.folder, month)
  if (!file.exists(ofolder)) {
    cat("[INFO] Creating Folder\n")
    dir.create(ofolder, recursive = T)
  }
  ofile <- paste0(ofolder, "/dt.car.conv.", month, ".RData")
  cat("[SAVE]", ofile, "\n")
  save(dt.car, file = ofile)
}
#---------------------------------------------------------------------------------------------------
option_list <- list(
  make_option(c("-m", "--month"), type = "character", default = NULL, help = "input date (YYYYMMDD)", 
              metavar = "character")
)

opt_parser <- OptionParser(option_list = option_list)
opt <- parse_args(opt_parser)

if (is.null(opt$month)) {
  print_help(opt_parser)
  stop("At least one parameter must be supplied (input month: YYYYMM)", call.=FALSE)
} else {
  main(opt$month)
}

print(warnings())
